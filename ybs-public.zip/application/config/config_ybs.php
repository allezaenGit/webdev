<?php
/*##############################################*/
/*	  WARNING !! JANGAN MENGEDIT FILE INI		*/
/*	( CONFIG INI DI UBAH MELALUI MENU SYSTEM )	*/
/*##############################################*/

$config['author']='Dhiya As Sayyaf';
$config['version']='2.0';
$config['email']='bridgin.system@gmail.com';
$config['domain']='';
$config['powored_by']='YBS SYSTEM | 2020';
$config['appname'] ="YBS-Application";

$config['login_title_bar']='YBS Application | Log in 2020';
$config['login_title_box']='Login to your account';
/*file in images/logo*/
$config['login_logo']='login.svg';
$config['login_logo_size']='9';//range 1-9
$config['login_label_user']='nama pengguna';
$config['login_label_password']='sandi';
$config['login_label_button']='Sign in';

$config['template_title_bar']='YBS Pages | 2020';

/*file in images/logo*/
$config['template_logo']='logo.svg';
$config['logo_title_bar']='logo_titlebar.svg';

$config['template_menu_title_mini']='<b>YBS</b>';
$config['template_menu_title_long']='<b>YBS</b> Sistem';
$config['template_logo_size']='';//range 1-9
$config['template_copyright']='Admin LTE';
$config['template_copyright_domain']='https://adminlte.io/';
$config['template_design_theme']='codecalm.net';
$config['template_design_theme_domain']='https://codecalm.net';
$config['template_footer_left']='© 2020 <a target="_blank" href="https://ybsapp.com">YBS Sistem</a>. Theme by <a href="https://adminlte.io/" target="_blank">Admin LTE</a> All rights reserved.';
$config['template_footer_right']='';

/* DEVELOPER SETTING */
$config['develop_by']='Dhiya As Sayyaf';
$config['develop_version']='v2.0';
$config['develop_domain']='https://ybsapp.com';
$config['develop_contact']='wa +6281342046414';
$config['develop_email']='bridging.system@gmail.com';


/*LOGIN STYLE*/
$config['login_style']='Style1';

/*email*/
$config['template_email_logo']='https://ybsapp.com/api/Public_Access/getFile/162656693025654_1626567150.png';

?>